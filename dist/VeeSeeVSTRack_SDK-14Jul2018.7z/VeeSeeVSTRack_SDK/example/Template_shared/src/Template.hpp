#include "rack.hpp"

using namespace rack;

RACK_PLUGIN_DECLARE(Template_shared);
