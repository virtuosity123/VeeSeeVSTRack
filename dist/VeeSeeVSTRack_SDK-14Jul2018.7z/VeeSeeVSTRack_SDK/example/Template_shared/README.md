
# VCV Template plugin

The VCV Template plugin is a starting point for developing your own plugins for VCV Rack.
It implements a simple sine VCO, demonstrating inputs, outputs, parameters, and other concepts.

See https://vcvrack.com/manual/PluginDevelopmentTutorial.html for a development tutorial.

## Contributing

I welcome Issues and Pull Requests to this repository if you have suggestions for improvement.

This template is released into the public domain ([CC0](https://creativecommons.org/publicdomain/zero/1.0/)).